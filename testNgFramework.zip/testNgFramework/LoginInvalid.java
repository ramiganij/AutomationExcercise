package testNgFramework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginInvalid {

	WebDriver driver;

	@BeforeTest
	public void homepage() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Documents\\Selenium\\Jars\\chromedriver.exe");
		ChromeOptions opt = new ChromeOptions();
		opt.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, opt);
		driver = new ChromeDriver(opt);
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}

	@Test
	public void logininvalid() {
		// login/signup
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// login into your account visible
		WebElement login = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/h2"));
		System.out.println("loginvisible-" + login.isDisplayed());
		// email
		driver.findElement(By.name("email")).sendKeys("ramigani@gmail.com");
		// password
		driver.findElement(By.name("password")).sendKeys("jaggubhai");
		// loginbutton
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/button")).click();
		WebElement incorrect = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/p"));
		System.out.println("incorrect-" + incorrect.isDisplayed());
	}
	@AfterTest
	public void close() {
		driver.quit();
	}
}
