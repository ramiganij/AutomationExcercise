package testNgFramework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class RegisterUser {

	WebDriver driver;
	@BeforeTest
	public void homepage() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\jaggubhai\\Documents\\Selenium\\Jars\\chromedriver.exe");
		ChromeOptions opt=new ChromeOptions();
		opt.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap=new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, opt);
		driver=new ChromeDriver(opt);
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}
	@Test
	public void register() {
		//signup/login page
	    WebElement register=driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a"));
	    System.out.println("sigup-"+register.isDisplayed());
	    register.click();
	    //username
	    driver.findElement(By.name("name")).sendKeys("Jagadeesh");
	    //mailid
	    driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]")).sendKeys("jaagad@gmail.com");
	    //sigupbutton
	    driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/button")).click();
	    //'ENTER ACCOUNT INFORMATION' visible
	    WebElement text=driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/h2/b"));
	    System.out.println("text visible-"+text.isDisplayed());
	    //gender radio button 
	    WebElement  radio=driver.findElement(By.id("id_gender1"));
	    radio.click();
	    System.out.println("radio button-"+radio.isSelected());
	    //passwordtab
	    driver.findElement(By.id("password")).sendKeys("jaggubhai");
	    //dob dd
	    WebElement daydd=driver.findElement(By.id("days"));
	    daydd.click();
	    Select day=new Select(daydd);
	    day.selectByValue("15");
	    WebElement monthdd=driver.findElement(By.id("months"));
	    monthdd.click();
	    Select month=new Select(monthdd);
	    month.selectByValue("6");
	    WebElement yeardd=driver.findElement(By.id("years"));
	    yeardd.click();
	    Select year=new Select(yeardd);
	    year.selectByValue("1995");
	    //check1
	    driver.findElement(By.id("newsletter")).click();
	    //check2
	    driver.findElement(By.id("optin")).click();
	    //fistnametab
	    driver.findElement(By.id("first_name")).sendKeys("Jagadeesh");
	    //lastanametab
	    driver.findElement(By.id("last_name")).sendKeys("ramigani");
	    //companynametab
	    driver.findElement(By.id("company")).sendKeys("infosys");
	    //add1 tab
	    driver.findElement(By.id("address1")).sendKeys("madhapur");
	    //add2 tab
	    driver.findElement(By.id("address2")).sendKeys("hitechcity");
	    //country dd
		WebElement country=driver.findElement(By.id("country"));
		country.click();
		Select countrydd=new Select(country);
		countrydd.selectByVisibleText("India");
		//state tab
		driver.findElement(By.id("state")).sendKeys("telengana");
		//city tab
		driver.findElement(By.id("city")).sendKeys("Hyderabad");
		//pincode tab
		driver.findElement(By.id("zipcode")).sendKeys("500081");
		//number tab
		driver.findElement(By.id("mobile_number")).sendKeys("9703394293");
		//create account button
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div[1]/form/button")).click();
		//'Account created' visible
		WebElement account=driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b"));
		System.out.println("account create-"+account.isDisplayed());
		//contiunue button
		driver.findElement(By.xpath("/html/body/section/div/div/div/div/a")).click();
		//logged in as username visble
		WebElement logged=driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a"));
		System.out.println("logged in as-"+logged.isDisplayed());
		//delete
		driver.findElement(By.xpath("/html/body/header/div/div/div/div[2]/div/ul/li[5]/a")).click();
		//account deleted visible
		WebElement delete=driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b"));
		System.out.println("account deleted-"+delete.isDisplayed());
		//continue
		driver.findElement(By.xpath("/html/body/section/div/div/div/div/a")).click();
	}
	@AfterTest
	public void close() {
		driver.quit();
	}
}
