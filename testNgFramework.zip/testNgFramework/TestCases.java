package testNgFramework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestCases {

	WebDriver driver;

	@BeforeTest
	public void homepage() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Documents\\Selenium\\Jars\\chromedriver.exe");
		ChromeOptions opt = new ChromeOptions();
		opt.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, opt);
		driver = new ChromeDriver(opt);
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}

	@Test
	public void testcases() {
		// testcase button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")).click();
		// testcase homepage visible
		WebElement testhome = driver.findElement(By.xpath("/html/body"));
		System.out.println("test home-" + testhome.isDisplayed());
	}

	@AfterTest
	public void close() {
		driver.quit();
	}
}
