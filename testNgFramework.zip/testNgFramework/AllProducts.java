package testNgFramework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AllProducts {

	WebDriver driver;

	@BeforeTest
	public void homepage() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Documents\\Selenium\\Jars\\chromedriver.exe");
		ChromeOptions opt = new ChromeOptions();
		opt.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, opt);
		driver = new ChromeDriver(opt);
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}

	@Test
	public void allproducts() {
		// Products Button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
		// product list visible
		WebElement plist = driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/h2"));
		System.out.println("product list-" + plist.isDisplayed());
		// view product
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[2]/ul/li/a")).click();
		// product detail visible
		WebElement pdetail = driver.findElement(By.className("product-information"));
		System.out.println("product details-" + pdetail.isDisplayed());
		// name visible
		WebElement name = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/h2"));
		System.out.println("name-" + name.isDisplayed());
		// category visble
		WebElement category = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[1]"));
		System.out.println("category-" + category.isDisplayed());
		// price visible
		WebElement price = driver
				.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/span"));
		System.out.println("price-" + price.isDisplayed());
		// avilability visible
		WebElement avilability = driver
				.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[2]/b"));
		System.out.println("avilability-" + avilability.isDisplayed());
		// condition visible
		WebElement condition = driver
				.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[3]/b"));
		System.out.println("condition-" + condition.isDisplayed());
		// brand visible
		WebElement brand = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[4]/b"));
		System.out.println("brand-" + brand.isDisplayed());
	}

	@AfterTest
	public void close() {
		driver.quit();
	}
}
