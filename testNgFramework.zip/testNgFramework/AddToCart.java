package testNgFramework;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AddToCart {
WebDriver driver;
	@BeforeTest
	public void homepage() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\jaggubhai\\Documents\\Selenium\\Jars\\chromedriver.exe");
		ChromeOptions opt=new ChromeOptions();
		opt.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap=new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, opt);
		driver=new ChromeDriver(opt);
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}
	@Test
	public void products() {
		//Products
	    driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
		 //Mouse hover on first product
		 WebElement firstcart=driver.findElement(By.xpath("(//div[@class='product-overlay'])[1]"));
		 Actions cart=new Actions(driver);
		 cart.moveToElement(firstcart).perform();
		 driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		 //add to cart 1
		 driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[1]/div[2]/div/a")).click();
		 driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		 //continue shopping 1
		 driver.findElement(By.xpath("//button[@class='btn btn-success close-modal btn-block']")).click();
		 driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		 //mouse hover on second product
		 WebElement secondcart=driver.findElement(By.xpath("(//div[@class='product-overlay'])[2]"));
		 Actions cart2=new Actions(driver);
		 cart2.moveToElement(secondcart).perform();
		 driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		 // add to cart 2
		 driver.findElement(By.xpath("//a[@data-product-id='2']")).click();
		 // view cart
		 driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")).click();
		 WebElement p1p2=driver.findElement(By.id("cart_info"));
		 System.out.println("product 1&2-"+p1p2.isDisplayed());
		 //prices
		String p1= driver.findElement(By.xpath("//*[@id=\"product-1\"]/td[3]/p")).getText();
		 System.out.println(p1);
		 String p2= driver.findElement(By.xpath("//*[@id=\"product-2\"]/td[3]/p")).getText();
		 System.out.println(p2);
		 //Quantity
		 String q1= driver.findElement(By.xpath("//*[@id=\"product-1\"]/td[4]/button")).getText();
		 System.out.println(q1);
		 String q2= driver.findElement(By.xpath("//*[@id=\"product-2\"]/td[4]/button")).getText();
		 System.out.println(q2);
		 //total price
		String t1= driver.findElement(By.xpath("//*[@id=\"product-1\"]/td[5]/p")).getText();
		 System.out.println(t1);
		 String t2= driver.findElement(By.xpath("//*[@id=\"product-2\"]/td[5]/p")).getText();
		 System.out.println(t2);
	}

	
	@AfterTest
	public void close() {
		driver.quit();
	}

}
