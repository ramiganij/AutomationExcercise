package testNgFramework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LogoutUser {

	WebDriver driver;

	@BeforeTest
	public void homepage() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Documents\\Selenium\\Jars\\chromedriver.exe");
		ChromeOptions opt = new ChromeOptions();
		opt.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, opt);
		driver = new ChromeDriver(opt);
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}

	@Test
	public void logout() {
		// login/signup
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// login into your account visible
		WebElement login = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/h2"));
		System.out.println("loginvisible-" + login.isDisplayed());
		// email
		driver.findElement(By.name("email")).sendKeys("ramigan@gmail.com");
		// password
		driver.findElement(By.name("password")).sendKeys("jaggubhai");
		// loginbutton
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/button")).click();
		// logged in as username visible
		WebElement logged = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a"));
		System.out.println("logged visible-" + logged.isDisplayed());
		// logout
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// return to login page verify
		WebElement returnlogin = driver.findElement(By.xpath("/html/body"));
		System.out.println("return loginpage-" + returnlogin.isDisplayed());
	}

@AfterTest
public void close() {
	driver.quit();
}
}
