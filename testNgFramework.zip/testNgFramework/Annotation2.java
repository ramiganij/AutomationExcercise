package testNgFramework;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Annotation2 {

	@Test
	public void test1 () {
		System.out.println("test1");
	}
	@Test
	public void test2 () {
		System.out.println("test2");
	}
	@Test
	public void test3 () {
		System.out.println("test3");
	}
	@BeforeTest
	public void bt () {
		System.out.println("bt");
	}
	@AfterTest
	public void at () {
		System.out.println("at");
	}
}
