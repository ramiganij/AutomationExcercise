package testNgFramework;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class RegisterUserWithExisting {

	WebDriver driver;

	@BeforeTest
	public void homepage() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Documents\\Selenium\\Jars\\chromedriver.exe");
		ChromeOptions opt = new ChromeOptions();
		opt.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, opt);
		driver = new ChromeDriver(opt);
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}

	@Test
	public void existingmail() {
		// login/signup
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// new user signup visible
		WebElement user = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/h2"));
		System.out.println("new user signup-" + user.isDisplayed());
		// username
		driver.findElement(By.name("name")).sendKeys("Jagadeesh");
		// mailid
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]"))
				.sendKeys("ramiganij@gmail.com");
		// sigupbutton
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/button")).click();
		// email already exist visible
		WebElement exist = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/p"));
		System.out.println("exist user-" + exist.isDisplayed());
	}

	@AfterTest
	public void close() {
		driver.quit();
	}
}
