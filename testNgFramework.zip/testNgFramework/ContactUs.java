package testNgFramework;

import java.io.File;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ContactUs {

	WebDriver driver;

	@BeforeTest
	public void homepage() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Documents\\Selenium\\Jars\\chromedriver.exe");
		ChromeOptions opt = new ChromeOptions();
		opt.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, opt);
		driver = new ChromeDriver(opt);
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}

	@Test
	public void contacus() throws Exception {
		// contact us
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[8]/a")).click();
		// get in touch verify
		WebElement touch = driver.findElement(By.xpath("//*[@id=\"contact-page\"]/div[2]/div[1]/div/h2"));
		System.out.println("get in touc-" + touch.isDisplayed());
		// name
		driver.findElement(By.name("name")).sendKeys("jagadeesh");
		// email
		driver.findElement(By.name("email")).sendKeys("ramiganij@gmail.com");
		// subjet
		driver.findElement(By.name("subject")).sendKeys("cart issue");
		// message
		driver.findElement(By.id("message")).sendKeys("cart not showing the products");
		// JavascriptExecutor js = (JavascriptExecutor) driver;
		// js.executeScript("window.scrollBy(0,450)");
		Thread.sleep(2000);
		// upload
		driver.findElement(By.name("upload_file")).sendKeys("C:\\Users\\jaggubhai\\Desktop\\pexels-pixabay-36029.jpg");
		Thread.sleep(2000);
		// submit button
		driver.findElement(By.name("submit")).click();
		Alert ok = driver.switchTo().alert();
		ok.accept();
		driver.findElement(By.xpath("//*[@id=\"form-section\"]/a")).click();
	}
	@AfterTest
	public void close() {
		driver.quit();
	}
}
