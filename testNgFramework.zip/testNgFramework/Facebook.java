package testNgFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Facebook {
	WebDriver driver;

	@BeforeTest
	public void launchapp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Documents\\Selenium\\Jars\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
	}

	@Test
	public void t1() {
		boolean email = driver.findElement(By.id("email")).isDisplayed();
		// hard assert
		//Assert.assertEquals(email, true);
		// soft assert
		SoftAssert s = new SoftAssert();
		s.assertEquals(email, false);
		boolean password = driver.findElement(By.id("pass")).isDisplayed();
		// hard assert
		Assert.assertEquals(password, true);
		// soft assert

		//s.assertEquals(password, true);
	}

	@Test
	public void t2() throws Exception {
		driver.findElement(By.id("email")).sendKeys("ramiganij@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("pass")).sendKeys("jaggubhai");
	}

	@AfterTest
	public void closeApp() {
		driver.close();
	}

}
