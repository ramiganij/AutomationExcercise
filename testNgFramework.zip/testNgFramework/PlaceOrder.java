package testNgFramework;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PlaceOrder {

	WebDriver driver;

	@BeforeTest
	public void homepage() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Documents\\Selenium\\Jars\\chromedriver.exe");
		ChromeOptions opt = new ChromeOptions();
		opt.addExtensions(new File("./Extensions/AdBlock.crx"));
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, opt);
		driver = new ChromeDriver(opt);
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}

	@Test
	public void whilecheckout() throws Exception {
		// Mouse hover on first product
		WebElement firstcart = driver
				.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]"));
		Actions cart = new Actions(driver);
		cart.moveToElement(firstcart).perform();
		Thread.sleep(2000);
		// add to cart
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div/a"))
				.click();
		Thread.sleep(2000);
		// continue shopping
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		// cart button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		// proceed to checkout
		driver.findElement(By.xpath("//*[@id=\"do_action\"]/div[1]/div/div/a")).click();
		// Register/Login
		driver.findElement(By.xpath("//*[@id=\"checkoutModal\"]/div/div/div[2]/p[2]/a/u")).click();
		// username
		driver.findElement(By.name("name")).sendKeys("Jagadeesh");
		// mailid
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]"))
				.sendKeys("jaaggu@gmail.com");
		// sigupbutton
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/button")).click();
		// gender radio button
		WebElement radio = driver.findElement(By.id("id_gender1"));
		radio.click();
		System.out.println("radio button-" + radio.isSelected());
		// passwordtab
		driver.findElement(By.id("password")).sendKeys("jaggubhai");
		// dob dd
		WebElement daydd = driver.findElement(By.id("days"));
		daydd.click();
		Select day = new Select(daydd);
		day.selectByValue("15");
		WebElement monthdd = driver.findElement(By.id("months"));
		monthdd.click();
		Select month = new Select(monthdd);
		month.selectByValue("6");
		WebElement yeardd = driver.findElement(By.id("years"));
		yeardd.click();
		Select year = new Select(yeardd);
		year.selectByValue("1995");
		// check1
		driver.findElement(By.id("newsletter")).click();
		// check2
		driver.findElement(By.id("optin")).click();
		// fistnametab
		driver.findElement(By.id("first_name")).sendKeys("Jagadeesh");
		// lastanametab
		driver.findElement(By.id("last_name")).sendKeys("ramigani");
		// companynametab
		driver.findElement(By.id("company")).sendKeys("infosys");
		// add1 tab
		driver.findElement(By.id("address1")).sendKeys("madhapur");
		// add2 tab
		driver.findElement(By.id("address2")).sendKeys("hitechcity");
		// country dd
		WebElement country = driver.findElement(By.id("country"));
		country.click();
		Select countrydd = new Select(country);
		countrydd.selectByVisibleText("India");
		// state tab
		driver.findElement(By.id("state")).sendKeys("telengana");
		// city tab
		driver.findElement(By.id("city")).sendKeys("Hyderabad");
		// pincode tab
		driver.findElement(By.id("zipcode")).sendKeys("500081");
		// number tab
		driver.findElement(By.id("mobile_number")).sendKeys("9703394293");
		// create account button
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div[1]/form/button")).click();
		// 'Account created' visible
		String account = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(account);
		// contiunue button
		driver.findElement(By.xpath("/html/body/section/div/div/div/div/a")).click();
		// logged in as username visble
		String logged = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a"))
				.getText();
		System.out.println(logged);
		// cart button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		// proceed to checkout
		driver.findElement(By.xpath("//*[@id=\"do_action\"]/div[1]/div/div/a")).click();
		// Address Details
		String adddetails = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[2]/h2")).getText();
		System.out.println(adddetails);
		// your delivery address
		String youradd = driver.findElement(By.id("address_delivery")).getText();
		System.out.println(youradd);
		// your billing
		String yourbilling = driver.findElement(By.id("address_invoice")).getText();
		System.out.println(yourbilling);
		// review order
		String review = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[4]/h2")).getText();
		System.out.println(review);
		// description
		driver.findElement(By.name("message")).sendKeys("product devlievr fast");
		// place order
		driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[7]/a")).click();
		// name on card
		driver.findElement(By.name("name_on_card")).sendKeys("Jagadeesh");
		// card number
		driver.findElement(By.name("card_number")).sendKeys("1234567890123456");
		// cvv
		driver.findElement(By.name("cvc")).sendKeys("234");
		// month
		driver.findElement(By.name("expiry_month")).sendKeys("05");
		// year
		driver.findElement(By.name("expiry_year")).sendKeys("2025");
		// submitt
		driver.findElement(By.id("submit")).click();
		// order placed
		String op = driver.findElement(By.xpath("//div[@class='alert-success alert']")).getText();
		System.out.println(op);
		// delete
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")).click();
		// account deleted visible
		String delete = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(delete);
		// continue
		driver.findElement(By.xpath("/html/body/section/div/div/div/div/a")).click();
	}

	@Test
	public void beforecheckout() throws Exception {
		// Signup/Login
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// username
		driver.findElement(By.name("name")).sendKeys("Jagadeesh");
		// mailid
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]"))
				.sendKeys("jaggu@gmail.com");
		// sigupbutton
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/button")).click();
		// gender radio button
		WebElement radio = driver.findElement(By.id("id_gender1"));
		radio.click();
		System.out.println("radio button-" + radio.isSelected());
		// passwordtab
		driver.findElement(By.id("password")).sendKeys("jaggubhai");
		// dob dd
		WebElement daydd = driver.findElement(By.id("days"));
		daydd.click();
		Select day = new Select(daydd);
		day.selectByValue("15");
		WebElement monthdd = driver.findElement(By.id("months"));
		monthdd.click();
		Select month = new Select(monthdd);
		month.selectByValue("6");
		WebElement yeardd = driver.findElement(By.id("years"));
		yeardd.click();
		Select year = new Select(yeardd);
		year.selectByValue("1995");
		// check1
		driver.findElement(By.id("newsletter")).click();
		// check2
		driver.findElement(By.id("optin")).click();
		// fistnametab
		driver.findElement(By.id("first_name")).sendKeys("Jagadeesh");
		// lastanametab
		driver.findElement(By.id("last_name")).sendKeys("ramigani");
		// companynametab
		driver.findElement(By.id("company")).sendKeys("infosys");
		// add1 tab
		driver.findElement(By.id("address1")).sendKeys("madhapur");
		// add2 tab
		driver.findElement(By.id("address2")).sendKeys("hitechcity");
		// country dd
		WebElement country = driver.findElement(By.id("country"));
		country.click();
		Select countrydd = new Select(country);
		countrydd.selectByVisibleText("India");
		// state tab
		driver.findElement(By.id("state")).sendKeys("telengana");
		// city tab
		driver.findElement(By.id("city")).sendKeys("Hyderabad");
		// pincode tab
		driver.findElement(By.id("zipcode")).sendKeys("500081");
		// number tab
		driver.findElement(By.id("mobile_number")).sendKeys("9703394293");
		// create account button
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div[1]/form/button")).click();
		// 'Account created' visible
		String account = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(account);
		// contiunue button
		driver.findElement(By.xpath("/html/body/section/div/div/div/div/a")).click();
		// logged in as username visble
		String logged = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a"))
				.getText();
		System.out.println(logged);
		Thread.sleep(2000);
		// mouse hover
		WebElement firstcart = driver
				.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]"));
		Actions cart = new Actions(driver);
		cart.moveToElement(firstcart).perform();
		Thread.sleep(2000);
		// add to cart
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div/a"))
				.click();
		Thread.sleep(2000);
		// continue shopping
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		// cart button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		// proceed to checkout
		driver.findElement(By.xpath("//*[@id=\"do_action\"]/div[1]/div/div/a")).click();
		// Address Details
		String adddetails = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[2]/h2")).getText();
		System.out.println(adddetails);
		// your delivery address
		String youradd = driver.findElement(By.id("address_delivery")).getText();
		System.out.println(youradd);
		// your billing
		String yourbilling = driver.findElement(By.id("address_invoice")).getText();
		System.out.println(yourbilling);
		// review order
		String review = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[4]/h2")).getText();
		System.out.println(review);
		// description
		driver.findElement(By.name("message")).sendKeys("product devlievr fast");
		// place order
		driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[7]/a")).click();
		// name on card
		driver.findElement(By.name("name_on_card")).sendKeys("Jagadeesh");
		// card number
		driver.findElement(By.name("card_number")).sendKeys("1234567890123456");
		// cvv
		driver.findElement(By.name("cvc")).sendKeys("234");
		// month
		driver.findElement(By.name("expiry_month")).sendKeys("05");
		// year
		driver.findElement(By.name("expiry_year")).sendKeys("2025");
		// submitt
		driver.findElement(By.id("submit")).click();
		Thread.sleep(2000);
		// delete
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")).click();
		// account deleted visible
		String delete = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(delete);
		// continue
		driver.findElement(By.xpath("/html/body/section/div/div/div/div/a")).click();
	}

	@Test
	public void logincheckout() throws Exception {
		// login/signup
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		// email
		driver.findElement(By.name("email")).sendKeys("ramigani@gmail.com");
		// password
		driver.findElement(By.name("password")).sendKeys("jaggubhai");
		// loginbutton
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/button")).click();
		// logged in as username visible
		WebElement logged = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a"));
		System.out.println("logged visible-" + logged.isDisplayed());
		// mouse hover
		WebElement firstcart = driver
				.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]"));
		Actions cart = new Actions(driver);
		cart.moveToElement(firstcart).perform();
		Thread.sleep(2000);
		// add to cart
		driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div/a"))
				.click();
		Thread.sleep(2000);
		// continue shopping
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		// cart button
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		// proceed to checkout
		driver.findElement(By.xpath("//*[@id=\"do_action\"]/div[1]/div/div/a")).click();
		// Address Details
		String adddetails = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[2]/h2")).getText();
		System.out.println(adddetails);
		// your delivery address
		String youradd = driver.findElement(By.id("address_delivery")).getText();
		System.out.println(youradd);
		// your billing
		String yourbilling = driver.findElement(By.id("address_invoice")).getText();
		System.out.println(yourbilling);
		// review order
		String review = driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[4]/h2")).getText();
		System.out.println(review);
		// description
		driver.findElement(By.name("message")).sendKeys("product devlievr fast");
		// place order
		driver.findElement(By.xpath("//*[@id=\"cart_items\"]/div/div[7]/a")).click();
		// name on card
		driver.findElement(By.name("name_on_card")).sendKeys("Jagadeesh");
		// card number
		driver.findElement(By.name("card_number")).sendKeys("1234567890123456");
		// cvv
		driver.findElement(By.name("cvc")).sendKeys("234");
		// month
		driver.findElement(By.name("expiry_month")).sendKeys("05");
		// year
		driver.findElement(By.name("expiry_year")).sendKeys("2025");
		// submitt
		driver.findElement(By.id("submit")).click();
		Thread.sleep(2000);
		// delete
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")).click();
		// account deleted visible
		String delete = driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/h2/b")).getText();
		System.out.println(delete);
		// continue
		driver.findElement(By.xpath("/html/body/section/div/div/div/div/a")).click();
	}

	@AfterTest
	public void close() {
		driver.quit();
	}
}
