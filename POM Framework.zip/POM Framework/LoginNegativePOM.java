package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginNegativePOM {

	@FindBy(xpath="//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")WebElement signup;
	@FindBy(name="email")WebElement email;
	@FindBy(name="password")WebElement pass;
	@FindBy(xpath="//*[@id=\"form\"]/div/div/div[1]/div/form/button")WebElement login;
	@FindBy(xpath = "//*[@id=\\\"header\\\"]/div/div/div/div[2]/div/ul/li[5]/a")WebElement delete;
}
