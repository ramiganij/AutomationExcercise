package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PORWCPOM {

	@FindBy(xpath="//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")WebElement signup;
	@FindBy(name="name")WebElement username;
	@FindBy(xpath="//*[@id=\\\"form\\\"]/div/div/div[3]/div/form/input[3]")WebElement email;	
	@FindBy(xpath="//*[@id=\\\"form\\\"]/div/div/div[3]/div/form/button")WebElement signupbutton;
	@FindBy(id="id_gender1")WebElement gender;
	@FindBy(id="password")WebElement password;
	@FindBy(id="days")WebElement daysdd;
	@FindBy(id="months")WebElement monthsdd;
	@FindBy(id="years")WebElement yearsdd;
	@FindBy(id="newsletter")WebElement box1;
	@FindBy(id="optin")WebElement box2;
	@FindBy(id="first_name")WebElement first;
	@FindBy(id="last_name")WebElement last;
	@FindBy(id="company")WebElement comp;
	@FindBy(id="address1")WebElement add1;
	@FindBy(id="address2")WebElement add2;
	@FindBy(id="country")WebElement countrydd;
	@FindBy(id="state")WebElement state;
	@FindBy(id="city")WebElement city;
	@FindBy(id="zipcode")WebElement code;
	@FindBy(id="mobile_number")WebElement mobile;
	@FindBy(xpath="//*[@id=\\\"form\\\"]/div/div/div/div[1]/form/button")WebElement createaccount;
	@FindBy(xpath="html/body/section/div/div/div/div/a")WebElement contin;
	@FindBy(xpath="/html/body/header/div/div/div/div[2]/div/ul/li[5]/a")WebElement delete;
	@FindBy(xpath="/html/body/section/div/div/div/div/a")WebElement contin1;
}
