package automationexcercise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ContactUsPOM {

	@FindBy(id="country")WebElement countrydd;
	@FindBy(id="state")WebElement state;
	@FindBy(id="city")WebElement city;
	@FindBy(id="zipcode")WebElement code;
	@FindBy(id="mobile_number")WebElement mobile;
	@FindBy(xpath="//*[@id=\\\"form\\\"]/div/div/div/div[1]/form/button")WebElement createaccount;
	@FindBy(xpath="html/body/section/div/div/div/div/a")WebElement contin;
	@FindBy(xpath="/html/body/header/div/div/div/div[2]/div/ul/li[5]/a")WebElement delete;
	@FindBy(xpath="/html/body/section/div/div/div/div/a")WebElement contin1;
}
